/*
 * mp_board.h
 *
 *  Created on: 2019-9-3
 *      Author: zhihui
 */

#ifndef MP_BOARD_H_
#define MP_BOARD_H_

#include <stdbool.h>

void InitMP();

void mp_processor();

#endif /* MP_BOARD_H_ */
