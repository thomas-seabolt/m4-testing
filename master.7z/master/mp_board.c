/*
 * mp_board.c
 *
 *  Created on: 2019-9-3
 *      Author: zhihui
 *
 *  This file perform the mp board connection, such uart connection,
 *  led controller, system power on / off.
 */

#include <stdbool.h>
#include "mp_board.h"
#include "mp_ledAction.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rpmsg_lite.h"
#include "rpmsg_queue.h"
#include "rpmsg_ns.h"
#include "board.h"
#include "fsl_debug_console.h"
#include "FreeRTOS.h"
#include "task.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_uart.h"
#include "rpmsg_lite.h"
#include "rpmsg_queue.h"
#include "rpmsg_ns.h"
#include "FreeRTOS.h"
#include "fsl_gpio.h"
#include "i2c.c"

#define UART UART4
#define UART_CLK_FREQ BOARD_DEBUG_UART_CLK_FREQ
#define UART_BAUDRATE 115200U
#define IRQn UART4_IRQn
#define UART_IRQHandler UART4_IRQHandler
#define RING_BUFFER_SIZE 4
#define MP_SYNC     0xA5
#define MP_RESP     0x3C
#define MP_CMDlEN 3
#define MP_CMDPOS 1
#define UINT8_MAX 0xFF
#define RPMSG_LITE_SHMEM_BASE (0xB8000000U)
#define RPMSG_LITE_LINK_ID (RL_PLATFORM_IMX8MM_M4_USER_LINK_ID)
#define RPMSG_LITE_NS_ANNOUNCE_STRING "rpmsg-virtual-tty-channel-1"
#define APP_TASK_STACK_SIZE (256)
#ifndef LOCAL_EPT_ADDR
#define LOCAL_EPT_ADDR (30)
#endif

static char app_buf[512]; /* Each RPMSG buffer can carry less than 512 payload */

typedef enum      // these value defined in MP to MPS430 interface document
{
	CMD_LEDArmed = 0x00,
	CMD_LEDBallInFlight = 0x01,
	CMD_LEDAwake = 0x02,
	CMD_LEDConfigure = 0x03,
	CMD_LEDError = 0x04,
	CMD_LEDSelfTest = 0x05,
	CMD_LEDWifiBtConn = 0x06,
	CMD_LEDStandby = 0x07,

	CMD_LEDAsleep = 0x10,
	CMD_REQ_ChargingStatus = 0x20,
	CMD_FAC_SelfCheck = 0x21,
	CMD_FAC_LEDOff = 0x22,
	CMD_REQ_NFC_ID = 0x30,
	CMD_REQ_ERR_STAT = 0x40,
	CMD_REQ_LED_STAT = 0x41,
	CMD_ILLEGAL = UINT8_MAX,
	CMD_OTHER = UINT8_MAX - 1,
} MP_COMMAND;

MP_COMMAND last_received_LED_cmd = CMD_OTHER;

enum MP_RESPONSE
{
	RESP_LEDArmed = CMD_LEDArmed,
	RESP_LEDBallInFlight = CMD_LEDBallInFlight,
	RESP_LEDAwake = CMD_LEDAwake,
	RESP_LEDConfigure = CMD_LEDConfigure,
	RESP_LEDError = CMD_LEDError,
	RESP_LEDSelfTest = CMD_LEDSelfTest,
	RESP_LEDWifiBtConn = CMD_LEDWifiBtConn,
	RESP_LEDStandby = CMD_LEDStandby,

	RESP_LEDAsleep = CMD_LEDAsleep,
	RESP_REQ_ChargingStatus = CMD_REQ_ChargingStatus,
	RESP_FAC_SelfCheck = CMD_FAC_SelfCheck,
	RESP_FAC_LEDOff = CMD_FAC_LEDOff,
	RESP_REQ_NFC_ID = CMD_REQ_NFC_ID,
	RESP_REQ_ERR_STAT = CMD_REQ_ERR_STAT,
	RESP_REQ_LED_STAT = CMD_REQ_LED_STAT,

	RESP_NONE = UINT8_MAX - 1,
	RESP_ILLEGAL = UINT8_MAX,
};

enum MP_STATUS
{
	MPSTA_ARMED,
	MPSTA_ILLEGAL = UINT8_MAX
}l_mpStatus = MPSTA_ILLEGAL;

enum MP_RESPONSE l_response;
uint8_t ringBuffer[RING_BUFFER_SIZE];
volatile uint16_t txIndex; /* Index of the data to send out. */
volatile uint16_t rxIndex; /* Index of the memory to save new arrived data. */
uint8_t cmd = 0xFF;

TaskHandle_t app_task_handle = NULL;

TaskHandle_t led_task_handle = NULL;

TaskHandle_t exec_task_handle = NULL;

void UART_IRQHandler(void)
{
	uint8_t data;
	/* If new data arrived. */
	if ((UART_GetStatusFlag(UART, kUART_RxDataReadyFlag)) || (UART_GetStatusFlag(UART, kUART_RxOverrunFlag)))
	{
		data = UART_ReadByte(UART);

		/* If ring buffer is not full, add data to ring buffer. */
		if (((rxIndex + 1) % RING_BUFFER_SIZE) != txIndex)
		{
			ringBuffer[rxIndex] = data;
			rxIndex++;
			rxIndex %= RING_BUFFER_SIZE;
		}
	}
	/* Add for ARM errata 838869, affects Cortex-M4, Cortex-M4F Store immediate overlapping
	exception return operation might vector to incorrect interrupt */
#if defined __CORTEX_M && (__CORTEX_M == 4U)
	__DSB();
#endif
}

void execMpCommand(/*uint8_t cmd*/)
{
	for (;;) {
		if (cmd != 0xFF) {
			switch (cmd)
			{
			case CMD_LEDArmed:          // A5 00 A5
				last_received_LED_cmd = (MP_COMMAND)cmd;
				/*if (!chg_isConnected())
				{
					lightoff();
					mpled_armed();
				}*/
				l_mpStatus = MPSTA_ARMED;
				l_response = RESP_LEDArmed;
				break;
			case CMD_LEDBallInFlight:   // A5 01 A4
				last_received_LED_cmd = (MP_COMMAND)cmd;
				lightoff();
				mpled_ballInFlight();
				l_response = RESP_LEDBallInFlight;
				break;
			case CMD_LEDAwake:          // A5 02 A7
				last_received_LED_cmd = (MP_COMMAND)cmd;
				lightoff();
				mpled_centerToOutside();
				l_response = RESP_LEDAwake;
				break;
			case CMD_LEDConfigure:      // A5 03 A6
				last_received_LED_cmd = (MP_COMMAND)cmd;
				lightoff();
				mpled_configuration();
				l_response = RESP_LEDConfigure;
				break;
			case CMD_LEDError:          // A5 04 A1
				last_received_LED_cmd = (MP_COMMAND)cmd;
				lightoff();
				mpled_error();
				l_response = RESP_LEDError;
				break;
			case CMD_LEDSelfTest:       // A5 05 A0
				last_received_LED_cmd = (MP_COMMAND)cmd;
				lightoff();
				mpled_selftest();
				l_response = RESP_LEDSelfTest;
				break;
			case CMD_LEDWifiBtConn:     // A5 06 A3
				last_received_LED_cmd = (MP_COMMAND)cmd;
				lightoff();
				mpled_wifiOrBtConn();
				l_response = RESP_LEDWifiBtConn;
				break;
			case CMD_LEDStandby:        // A5 07 A2
				last_received_LED_cmd = (MP_COMMAND)cmd;
				lightoff();
				mpled_standby();
				l_response = RESP_LEDStandby;
				break;
			case CMD_LEDAsleep:         // A5 10 AD
				last_received_LED_cmd = (MP_COMMAND)cmd;
				lightoff();
				mpled_outsideToCenter();
				//MP_asleep();            // issue command to go asleep
				break;
			case CMD_REQ_ChargingStatus:
				l_response = RESP_REQ_ChargingStatus;
				break;
			case CMD_FAC_SelfCheck:
				l_response = RESP_FAC_SelfCheck;
				break;
			case CMD_FAC_LEDOff:
				last_received_LED_cmd = (MP_COMMAND)cmd;
				lightoff();
				mpled_clear();
				l_response = RESP_FAC_LEDOff;
				break;
			case CMD_REQ_NFC_ID:
				l_response = RESP_REQ_NFC_ID;
				break;
			case CMD_REQ_ERR_STAT:
				l_response = RESP_REQ_ERR_STAT;
				break;
			case CMD_REQ_LED_STAT:
				l_response = RESP_REQ_LED_STAT;
				break;
			default:
				l_response = RESP_ILLEGAL;
				break;
			}
			cmd = 0xFF;
		}
		mpled_processor();
	}
}

//
//void MP_asleep()
//{
//	volatile unsigned int i;
//	volatile unsigned int j;
//	//Check if MP_Ready high before sending pulse
//	if (MP_ready_on()) {
//		MP_Enable(true);
//		MP_Enable(false);
//		for (i = 15000; i > 0; i--) {
//			for (j = 100; j >0; j--);
//		} //busy wait MP Board looking for pulse on MP_Enable to power asleep
//		MP_Enable(true);
//	}
//	MP_EnableZYNQ(false);
//	l_sysMode = SYSM_ASLEEP;
//	mpled_outsideToCenter();
//}
//
//void MP_awake()
//{
//	volatile unsigned int i;
//	volatile unsigned int j;
//	//Power on all boards.
//	if (!MP_ready_on()) {
//		MP_Enable(true);
//		MP_Enable(false);
//		for (i = 15000; i > 0; i--) {
//			for (j = 100; j > 0; j--);
//		}
//		MP_Enable(true);
//	}
//	MP_EnableZYNQ(true);
//	l_sysMode = SYSM_AWAKE;
//	mpled_centerToOutside();
//}

void InitMP()
{
	mpled_init();
	mpled_centerToOutside();        // this is the 'turn on' indicator
	PRINTF("\r\nInitialized LEDs.\r\n");
	status_t status;
	//uart_config_t config;
	//UART_GetDefaultConfig(&config);
	//config.baudRate_Bps = UART_BAUDRATE;
	//config.enableTx = true;
	//config.enableRx = true;
	/*status = UART_Init(UART, &config, UART_CLK_FREQ);
	if (kStatus_Success != status)
	{
		PRINTF("\r\nuart failed to initialize\r\n");
		return;
	}*/
	/* Enable RX interrupt. */
	/*UART_EnableInterrupts(UART, kUART_RxDataReadyEnable | kUART_RxOverrunEnable);
	EnableIRQ(IRQn);*/
	PRINTF("\r\nuart enabled\r\n");
}

// this is polled by main
uint8_t parseFrame(uint8_t sync, uint8_t len, uint8_t cmdpos)
{
	uint8_t ret = 0xFF; // assume no command
	if (rxIndex == 3) {
		ret = ringBuffer[1];
		rxIndex = 0;      // tell interrupt to start over
	}
	return ret;
}


void app_nameservice_isr_cb(uint32_t new_ept, const char *new_ept_name, uint32_t flags, void *user_data)
{
}

void led_task(void *params) {
	for (;;) {
		mpled_processor();
	}
}

void app_task(void *param)
{
	volatile uint32_t remote_addr;
	struct rpmsg_lite_endpoint *volatile my_ept;
	volatile rpmsg_queue_handle my_queue;
	struct rpmsg_lite_instance *volatile my_rpmsg;
	void *rx_buf;
	uint32_t len;
	int32_t result;
	void *tx_buf;
	uint32_t size;

	/* Print the initial banner */
	PRINTF("\r\nRPMSG String Echo FreeRTOS RTOS API Demo...\r\n");

//#ifdef MCMGR_USED
//	uint32_t startupData;
//
//	/* Get the startup data */
//	MCMGR_GetStartupData(kMCMGR_Core1, &startupData);
//
//	my_rpmsg = rpmsg_lite_remote_init((void *)startupData, RPMSG_LITE_LINK_ID, RL_NO_FLAGS);
//
//	/* Signal the other core we are ready */
//	MCMGR_SignalReady(kMCMGR_Core1);
//#else
	my_rpmsg = rpmsg_lite_remote_init((void *)RPMSG_LITE_SHMEM_BASE, RPMSG_LITE_LINK_ID, RL_NO_FLAGS);
//#endif /* MCMGR_USED */

	while (!rpmsg_lite_is_link_up(my_rpmsg))
		;

	my_queue = rpmsg_queue_create(my_rpmsg);
	my_ept = rpmsg_lite_create_ept(my_rpmsg, LOCAL_EPT_ADDR, rpmsg_queue_rx_cb, my_queue);
	rpmsg_ns_bind(my_rpmsg, app_nameservice_isr_cb, NULL);
	rpmsg_ns_announce(my_rpmsg, my_ept, RPMSG_LITE_NS_ANNOUNCE_STRING, RL_NS_CREATE);

	PRINTF("\r\nNameservice sent, ready for incoming messages...\r\n");
	int reinit_flag = 0;
	for (;;)
	{
		/* Get RPMsg rx buffer with message */
		PRINTF("\r\ntest printf working before rpmsg_queue_recv_nocopy\r\n");
		result =
			rpmsg_queue_recv_nocopy(my_rpmsg, my_queue, (uint32_t *)&remote_addr, (char **)&rx_buf, &len, RL_BLOCK);
		PRINTF("\r\ntest printf working after rpmsg_queue_recv_nocopy\r\n");
		if (reinit_flag == 0) {
			initI2C();
			InitMP();
			reinit_flag = 1;
		}
		if (result != 0)
		{
			assert(false);
		}

		/* Copy string from RPMsg rx buffer */
		assert(len < sizeof(app_buf));
		memcpy(app_buf, rx_buf, len);
		app_buf[len] = 0; /* End string by '\0' */

		if ((len == 2) && (app_buf[0] == 0xd) && (app_buf[1] == 0xa)) {
			PRINTF("\r\nGet New Line From Master Side\r\n");
		}
		else {
			PRINTF("Get Message From Master Side : \"%s\" [len : %d]\r\n", app_buf, len);
			// = app_buf;// ((uint8_t)app_buf[0] * 0x10) + ((uint8_t)app_buf[1] * 0x01);
			sscanf(app_buf, "%x", &cmd);
			PRINTF("\r\n%x\r\n",  cmd);
		}

		/* Get tx buffer from RPMsg */
		tx_buf = rpmsg_lite_alloc_tx_buffer(my_rpmsg, &size, RL_BLOCK);
		assert(tx_buf);
		/* Copy string to RPMsg tx buffer */
		memcpy(tx_buf, app_buf, len);
		/* Echo back received message with nocopy send */
		result = rpmsg_lite_send_nocopy(my_rpmsg, my_ept, remote_addr, tx_buf, len);
		if (result != 0)
		{
			assert(false);
		}
		/* Release held RPMsg rx buffer */
		result = rpmsg_queue_nocopy_free(my_rpmsg, rx_buf);
		if (result != 0)
		{
			assert(false);
		}
	}
}

void mp_processor()
{
	/* Send data only when UART TX register is empty and ring buffer has data to send out. */
	/*while ((UART_GetStatusFlag(UART, kUART_TxReadyFlag)) && (rxIndex != txIndex))
	{
		UART_WriteByte(UART, ringBuffer[txIndex]);
		execMpCommand(ringBuffer[txIndex]);
		txIndex++;
		txIndex %= RING_BUFFER_SIZE;
	}*/

//#ifdef MCMGR_USED
//	/* Initialize MCMGR before calling its API */
//	MCMGR_Init();
//#endif /* MCMGR_USED */

	if (xTaskCreate(app_task, "APP_TASK", 512, NULL, tskIDLE_PRIORITY + 3, &app_task_handle) != pdPASS)
	{
		PRINTF("\r\nFailed to create application task\r\n");
		while(1)
			;
	}

	/*if (xTaskCreate(led_task, "LED_TASK", 512, NULL, tskIDLE_PRIORITY + 1, &led_task_handle) != pdPASS)
	{
		PRINTF("\r\nFailed to create application task\r\n");
		while (1)
			;
	}*/

	if (xTaskCreate(execMpCommand, "exec_mp_command", 512, NULL, tskIDLE_PRIORITY + 2, &exec_task_handle) != pdPASS)
	{
		PRINTF("\r\nFailed to create application task\r\n");
		while (1)
			;
	}
	vTaskStartScheduler();
	
	while (1) {
		PRINTF("Failed to start FreeRTOS on core0.\n");
	}
		;
	//mpled_processor();
}
