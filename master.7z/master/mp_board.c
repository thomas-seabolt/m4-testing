/*
 * mp_board.c
 *
 *  Created on: 2019-9-3
 *      Author: zhihui
 *
 *  This file perform the mp board connection, such uart connection,
 *  led controller, system power on / off.
 */
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "mp_board.h"
#include "mp_ledAction.h"
#include "fsl_uart.h"
#include "board.h"
#include "fsl_debug_console.h"

#define UART UART4
#define UART_CLK_FREQ BOARD_DEBUG_UART_CLK_FREQ
#define UART_BAUDRATE 115200U
#define IRQn UART4_IRQn
#define UART_IRQHandler UART4_IRQHandler
#define RING_BUFFER_SIZE 4
#define MP_SYNC     0xA5
#define MP_RESP     0x3C
#define MP_CMDlEN 3
#define MP_CMDPOS 1
#define UINT8_MAX 0xFF


typedef enum      // these value defined in MP to MPS430 interface document
{
	CMD_LEDArmed = 49,
	CMD_LEDBallInFlight = 50,
	CMD_LEDAwake = 51,
	CMD_LEDConfigure = 52,
	CMD_LEDError = 53,
	CMD_LEDSelfTest = 54,
	CMD_LEDWifiBtConn = 55,
	CMD_LEDStandby = 56,

	CMD_LEDAsleep = 57,
	CMD_REQ_ChargingStatus = 58,
	CMD_FAC_SelfCheck = 59,
	CMD_FAC_LEDOff = 60,
	CMD_REQ_NFC_ID = 61,
	CMD_REQ_ERR_STAT = 62,
	CMD_REQ_LED_STAT = 63,
	CMD_ILLEGAL = UINT8_MAX,
	CMD_OTHER = UINT8_MAX - 1,
} MP_COMMAND;


MP_COMMAND last_received_LED_cmd = CMD_OTHER;

enum MP_RESPONSE
{
	RESP_LEDArmed = CMD_LEDArmed,
	RESP_LEDBallInFlight = CMD_LEDBallInFlight,
	RESP_LEDAwake = CMD_LEDAwake,
	RESP_LEDConfigure = CMD_LEDConfigure,
	RESP_LEDError = CMD_LEDError,
	RESP_LEDSelfTest = CMD_LEDSelfTest,
	RESP_LEDWifiBtConn = CMD_LEDWifiBtConn,
	RESP_LEDStandby = CMD_LEDStandby,

	RESP_LEDAsleep = CMD_LEDAsleep,
	RESP_REQ_ChargingStatus = CMD_REQ_ChargingStatus,
	RESP_FAC_SelfCheck = CMD_FAC_SelfCheck,
	RESP_FAC_LEDOff = CMD_FAC_LEDOff,
	RESP_REQ_NFC_ID = CMD_REQ_NFC_ID,
	RESP_REQ_ERR_STAT = CMD_REQ_ERR_STAT,
	RESP_REQ_LED_STAT = CMD_REQ_LED_STAT,

	RESP_NONE = UINT8_MAX - 1,
	RESP_ILLEGAL = UINT8_MAX,
};

enum MP_STATUS
{
	MPSTA_ARMED,
	MPSTA_ILLEGAL = UINT8_MAX
}l_mpStatus = MPSTA_ILLEGAL;

enum MP_RESPONSE l_response;
uint8_t ringBuffer[RING_BUFFER_SIZE];
volatile uint16_t txIndex; /* Index of the data to send out. */
volatile uint16_t rxIndex; /* Index of the memory to save new arrived data. */


void UART_IRQHandler(void)
{
	uint8_t data;

	/* If new data arrived. */
	if ((UART_GetStatusFlag(UART, kUART_RxDataReadyFlag)) || (UART_GetStatusFlag(UART, kUART_RxOverrunFlag)))
	{
		data = UART_ReadByte(UART);

		/* If ring buffer is not full, add data to ring buffer. */
		if (((rxIndex + 1) % RING_BUFFER_SIZE) != txIndex)
		{
			ringBuffer[rxIndex] = data;
			rxIndex++;
			rxIndex %= RING_BUFFER_SIZE;
		}
	}
	/* Add for ARM errata 838869, affects Cortex-M4, Cortex-M4F Store immediate overlapping
	exception return operation might vector to incorrect interrupt */
#if defined __CORTEX_M && (__CORTEX_M == 4U)
	__DSB();
#endif
}



void execMpCommand(uint8_t cmd)
{

	if (cmd != 0xFF) {
		switch (cmd)
		{
		case CMD_LEDArmed:          // A5 00 A5
			last_received_LED_cmd = (MP_COMMAND)cmd;
			/*if (!chg_isConnected())
			{
				lightoff();
				mpled_armed();
			}*/
			l_mpStatus = MPSTA_ARMED;
			l_response = RESP_LEDArmed;
			break;
		case CMD_LEDBallInFlight:   // A5 01 A4
			last_received_LED_cmd = (MP_COMMAND)cmd;
			lightoff();
			mpled_ballInFlight();
			l_response = RESP_LEDBallInFlight;
			break;
		case CMD_LEDAwake:          // A5 02 A7
			last_received_LED_cmd = (MP_COMMAND)cmd;
			lightoff();
			mpled_centerToOutside();
			l_response = RESP_LEDAwake;
			break;
		case CMD_LEDConfigure:      // A5 03 A6
			last_received_LED_cmd = (MP_COMMAND)cmd;
			lightoff();
			mpled_configuration();
			l_response = RESP_LEDConfigure;
			break;
		case CMD_LEDError:          // A5 04 A1
			last_received_LED_cmd = (MP_COMMAND)cmd;
			lightoff();
			mpled_error();
			l_response = RESP_LEDError;
			break;
		case CMD_LEDSelfTest:       // A5 05 A0
			last_received_LED_cmd = (MP_COMMAND)cmd;
			lightoff();
			mpled_selftest();
			l_response = RESP_LEDSelfTest;
			break;
		case CMD_LEDWifiBtConn:     // A5 06 A3
			last_received_LED_cmd = (MP_COMMAND)cmd;
			lightoff();
			mpled_wifiOrBtConn();
			l_response = RESP_LEDWifiBtConn;
			break;
		case CMD_LEDStandby:        // A5 07 A2
			last_received_LED_cmd = (MP_COMMAND)cmd;
			lightoff();
			mpled_standby();
			l_response = RESP_LEDStandby;
			break;
		case CMD_LEDAsleep:         // A5 10 AD
			last_received_LED_cmd = (MP_COMMAND)cmd;
			lightoff();
			mpled_outsideToCenter();
		//	MP_asleep();            // issue command to go asleep
			break;
		case CMD_REQ_ChargingStatus:
			l_response = RESP_REQ_ChargingStatus;
			break;
		case CMD_FAC_SelfCheck:
			l_response = RESP_FAC_SelfCheck;
			break;
		case CMD_FAC_LEDOff:
			last_received_LED_cmd = (MP_COMMAND)cmd;
			lightoff();
			mpled_clear();
			l_response = RESP_FAC_LEDOff;
			break;
		case CMD_REQ_NFC_ID:
			l_response = RESP_REQ_NFC_ID;
			break;
		case CMD_REQ_ERR_STAT:
			l_response = RESP_REQ_ERR_STAT;
			break;
		case CMD_REQ_LED_STAT:
			l_response = RESP_REQ_LED_STAT;
			break;
		default:
			l_response = RESP_ILLEGAL;
			break;
		}
	}
}


void InitMP()
{

	mpled_init();
	mpled_centerToOutside();        // this is the 'turn on' indicator
	PRINTF("\r\nInitialized LEDs.\r\n");
	status_t status;
	uart_config_t config;
	UART_GetDefaultConfig(&config);
	config.baudRate_Bps = UART_BAUDRATE;
	config.enableTx = true;
	config.enableRx = true;
	status = UART_Init(UART, &config, UART_CLK_FREQ);
	if (kStatus_Success != status)
	{
		PRINTF("\r\nuart failed to initialize\r\n");
		return kStatus_Fail;
	}

	/* Enable RX interrupt. */
	UART_EnableInterrupts(UART, kUART_RxDataReadyEnable | kUART_RxOverrunEnable);
	EnableIRQ(IRQn);
	PRINTF("\r\nuart enabled\r\n");
}

// this is polled by main
uint8_t parseFrame(uint8_t sync, uint8_t len, uint8_t cmdpos)
{
	uint8_t ret = 0xFF; // assume no command
	if (rxIndex == 3) {
		ret = ringBuffer[1];
		rxIndex = 0;      // tell interrupt to start over
	}
	return ret;
}

void mp_processor()
{
	/* Send data only when UART TX register is empty and ring buffer has data to send out. */
	while ((UART_GetStatusFlag(UART, kUART_TxReadyFlag)) && (rxIndex != txIndex))
	{
		UART_WriteByte(UART, ringBuffer[txIndex]);
		execMpCommand(ringBuffer[txIndex]);
		txIndex++;
		txIndex %= RING_BUFFER_SIZE;
	}
	mpled_processor();
}
