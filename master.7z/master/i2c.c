/*
 * i2c.c
 *
 *  Created on: 2019-9-3
 *      Author: zhihui
 */
#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/time.h>
#include "i2c.h"
#include "fsl_i2c.h"
#include "fsl_gpio.h"
#include "fsl_debug_console.h"
#include "pin_mux.h"
#include "clock_config.h"

#define MAX_BUFFER_SIZE     20

#define BIGENDIANCNT    4


#define I2C_BAUDRATE 100000U
#define I2C_DATA_LENGTH 2U
#define LED_EN_GPIO GPIO1
#define LED_EN_GPIO_PIN 12U
#define EXAMPLE_I2C_MASTER_BASEADDR I2C2
#define I2C_MASTER_CLK_FREQ                                                                 \
    (CLOCK_GetPllFreq(kCLOCK_SystemPll1Ctrl) / (CLOCK_GetRootPreDivider(kCLOCK_RootI2c2)) / \
     (CLOCK_GetRootPostDivider(kCLOCK_RootI2c2)) / 5) /* SYSTEM PLL1 DIV5 */

I2C_Mode MasterMode = IDLE_MODE;

uint8_t TransmitRegAddr = 0;

uint8_t ReceiveBuffer[MAX_BUFFER_SIZE] = {0};
uint8_t RXByteCtr = 0;
uint8_t ReceiveIndex = 0;
uint8_t TransmitBuffer[MAX_BUFFER_SIZE] = {0};
uint8_t TXByteCtr = 0;
uint8_t TransmitIndex = 0;

bool    l_flgTransimit;
bool    l_flgNack;
bool    l_i2cWorking;
uint8_t l_bigEndianDev[BIGENDIANCNT] = {0};
uint8_t l_bigEndianDevEnd = 0;


volatile bool g_MasterCompletionFlag = false;
volatile bool g_pinSet = false;
#define DELAY 10000

#define START_DELAY 100
volatile uint16_t delay;

void wait()
{   // this function needs to be finetuned for the specific microprocessor
	int i, j, k;
	for (i = 0; i < 1; i++)
	{
		for (j = 0; j < 500; j++)
		{
			for (k = 0; k < 1000; k++)
			{   // waste function, volatile makes sure it is not being optimized out by compiler
				if (g_MasterCompletionFlag == true) {
					PRINTF("\r\ncompleted.\r\n");
					k = 1000;
					j = 500;
					i = 1;
				}
			}
		}
		if (i == 0) {
			//PRINTF("\r\ntimed out.\r\n");
			//I2C_MasterTransferAbort(EXAMPLE_I2C_MASTER_BASEADDR, &g_m_handle);
		}
	}
	g_MasterCompletionFlag = false;
}

static void i2c_master_callback(I2C_Type *base, i2c_master_handle_t *handle, status_t status, void *userData)
{
	/* Signal transfer finished when received success or timeout status. */
	if (status == kStatus_Success || status == kStatus_I2C_Timeout)
	{
		if (status == kStatus_I2C_Timeout) {
			PRINTF("\r\timed out.\r\n");
		}
		g_MasterCompletionFlag = true;
	}
}


void I2C_Master_WriteBy1(uint8_t dev_addr, uint8_t reg_addr, uint8_t reg_data)
{
	PRINTF("\r\n%x    %x    %x\r\n", dev_addr, reg_addr, reg_data);
	uint8_t g_master_txBuff[2];
	i2c_master_handle_t g_m_handle;
	i2c_master_transfer_t masterXfer;
	memset(&g_m_handle, 0, sizeof(g_m_handle));
	memset(&masterXfer, 0, sizeof(masterXfer));
	g_master_txBuff[0] = reg_addr;
	g_master_txBuff[1] = reg_data;
	masterXfer.slaveAddress = dev_addr;
	masterXfer.direction = kI2C_Write;
	masterXfer.subaddress = (uint32_t)NULL;
	masterXfer.subaddressSize = 0;
	masterXfer.data = g_master_txBuff;
	masterXfer.dataSize = 2U;
	masterXfer.flags = kI2C_TransferDefaultFlag;
	I2C_MasterTransferCreateHandle(EXAMPLE_I2C_MASTER_BASEADDR, &g_m_handle, i2c_master_callback, NULL);
	I2C_MasterTransferNonBlocking(EXAMPLE_I2C_MASTER_BASEADDR, &g_m_handle, &masterXfer);
	wait();
}

void I2C_Master_WriteBy2(uint8_t dev_addr, uint8_t reg_addr, uint16_t reg_data)
{
	PRINTF("\r\n%x    %x    %x\r\n", dev_addr, reg_addr, reg_data);
	uint8_t g_master_txBuff2[3];
	i2c_master_handle_t g_m_handle;
	i2c_master_transfer_t masterXfer;
	memset(&g_m_handle, 0, sizeof(g_m_handle));
	memset(&masterXfer, 0, sizeof(masterXfer));
	g_master_txBuff2[0] = reg_addr;
	g_master_txBuff2[1] = (uint8_t)(reg_data / 0x0100);
	g_master_txBuff2[2] = (uint8_t)(reg_data % 0x0100);
	masterXfer.slaveAddress = dev_addr;
	masterXfer.direction = kI2C_Write;
	masterXfer.subaddress = (uint32_t)NULL;
	masterXfer.subaddressSize = 0;
	masterXfer.data = g_master_txBuff2;
	masterXfer.dataSize = 3U;
	masterXfer.flags = kI2C_TransferDefaultFlag;
	I2C_MasterTransferCreateHandle(EXAMPLE_I2C_MASTER_BASEADDR, &g_m_handle, i2c_master_callback, NULL);
	I2C_MasterTransferNonBlocking(EXAMPLE_I2C_MASTER_BASEADDR, &g_m_handle, &masterXfer);
	wait();
}


void initI2C()
{
	gpio_pin_config_t led_config = { kGPIO_DigitalOutput, 0, kGPIO_NoIntmode };
	GPIO_PinInit(LED_EN_GPIO, LED_EN_GPIO_PIN, &led_config);
	wait();
	GPIO_PinWrite(LED_EN_GPIO, LED_EN_GPIO_PIN, 1U);
	wait();
	GPIO_PinWrite(LED_EN_GPIO, LED_EN_GPIO_PIN, 0U);
	wait();
	GPIO_PinWrite(LED_EN_GPIO, LED_EN_GPIO_PIN, 1U);
	/* Set up i2c master to send data to slave*/
	/*i2c settings*/
	CLOCK_SetRootMux(kCLOCK_RootI2c2, kCLOCK_I2cRootmuxSysPll1Div5); /* Set I2C source to SysPLL1 Div5 160MHZ */
	CLOCK_SetRootDivider(kCLOCK_RootI2c2, 1U, 10U);                  /* Set root clock to 160MHZ / 10 = 16MHZ */
	i2c_master_config_t masterConfig;
	uint32_t sourceClock;
	I2C_MasterGetDefaultConfig(&masterConfig);
	masterConfig.baudRate_Bps = I2C_BAUDRATE;
	sourceClock = I2C_MASTER_CLK_FREQ;
	I2C_MasterInit(EXAMPLE_I2C_MASTER_BASEADDR, &masterConfig, sourceClock);
	I2C_EnableInterrupts(EXAMPLE_I2C_MASTER_BASEADDR, 0xFFFFFFFF);

}

void initI2CGPIO()
{
	gpio_pin_config_t led_config = { kGPIO_DigitalOutput, 0, kGPIO_NoIntmode };
	gpio_pin_config_t led_config2 = { kGPIO_DigitalInput, 0, kGPIO_NoIntmode };
	///* Init output LED GPIO. */
	GPIO_PinInit(LED_EN_GPIO, LED_EN_GPIO_PIN, &led_config);
	GPIO_PinWrite(LED_EN_GPIO, LED_EN_GPIO_PIN, 1U);
	GPIO_PinInit(LED_EN_GPIO, 11U, &led_config2);
}

