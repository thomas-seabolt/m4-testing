/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/*  Standard C Included Files */
#include <string.h>
#include <time.h>
/*  SDK Included Files */
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_i2c.h"
#include "fsl_gpio.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "mp_ledAction.h"
#include "i2c.h"
#include "mp_board.h"

int main(void)
{
	PRINTF("\r\nInitialized main.\r\n");
    /* Board specific RDC settings */
    BOARD_RdcInit();
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    BOARD_InitMemory();
	PRINTF("\r\nInitialized board.\r\n");
	initI2CGPIO();
	PRINTF("\r\nInitialized I2C GPIO.\r\n");
	initI2C();
	PRINTF("\r\nInitialized I2C.\r\n");
	InitMP();
   // while (1)
    //{		
		mp_processor();
    //}
}
