/*
 * mp_ledAction.c
 *
 *  Created on: 2019-9-6
 *      Author: zhihui
 *
 *  This file perform the LED actions.
 *
 *  There is a calling step, which is like the LED_ACTEST in the mp_board.c:
 *  1. Call the mpled_init.
 *  2. Call lightoff() and the LED action, such as mpled_outsideToCenter().
 *  And then, the LED action will be auto proceeded by the mpled_processor.
 *
 *  We can create a new LED action like this.
 *  1. Separate the LED behavior to single steps, which is the status of every LED.
 *  2. Promote the LED behavior step by step.
 *  3. Create a LEDACTION, and append it to the LED action queue.
 */
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include "mp_ledAction.h"
#include "lp55231.h"
#include "i2c.h"
#include "acc.h"
#include "fsl_debug_console.h"

//inside one chip, n [0, 1, 2]
#define LEDINSIDE   3
#define BLUE(n)     (0x02 << multipInt16((n), 2))
#define GREE(n)     (0x01 << multipInt16((n), 2))
#define RED(n)      (0x40 << (n))
#define YELL(n)     (RED(n) | GREE(n))
#define WHITE(n)    (BLUE(n) | GREE(n) | RED(n))
#define DARK        0
#define BLACK(n)    &=~WHITE(n)

#define SINGPWMDEF  0x05
#define BRIGHTSTEP  0x0F

#define CHIPLEN     sizeof(ledctlChips)

#define LACTIONDEEP 1
#define ACTION_MAX  CHIPLEN

#define LED_INTERR BIT3
#define LED_ENABLE BIT0


const uint8_t ledctlChips[] =
{
 LP55231_SLAVE0,
 LP55231_SLAVE1,
 LP55231_SLAVE2,
 LP55231_SLAVE3
};
uint16_t l_regColor[] = {DARK, DARK, DARK, DARK};

typedef struct LEDACTION_t
{
    uint16_t    m_delay;    //In ms
//    struct
//    {
//        uint8_t     m_chipId;
//        uint8_t     m_register;
//        uint16_t    m_regData;  //In little endian
//    }           m_actions[ACTION_MAX];
//    uint8_t     m_actionEnd;
    void        (*m_stepnext)(void);
}LEDACTION;

/*
 * A queue about the separated led actions.
 */
LEDACTION   l_queLAction[LACTIONDEEP];

/*
 * The separated led actions queue size
 */
uint8_t     l_queLActend;

void        *l_ledElapseTimer;

enum LEDCOLORS
{
    LEDC_RED,
    LEDC_GREEN,
    LEDC_BLUE,
    LEDC_YELLOW,
    LEDC_WHITE,
};

/*
 * Blink the led between ledBeg and ledEnd(not include), with specified color and half period.
 */
static void blink(uint8_t ledBeg, uint8_t ledEnd, enum LEDCOLORS color, uint16_t halfPeriod, void (*stepnext)(void));

/*
 * Append a new action to the LED actions queue.
 */
static void mpled_append(LEDACTION *action);

/*
 * Replace the LED action in LED queue position of cursor with a new action.
 */
static void mpled_replace(LEDACTION *action, uint8_t cursor);

/*
 * Insert a new action to the LED queue position of cursor.
 */
static void mpled_insert(LEDACTION *action, uint8_t cursor);

void lightoff()
{
	uint8_t len = sizeof(ledctlChips);
	while (len--)
	{
		l_regColor[len] = DARK;
		I2C_Master_WriteBy2(ledctlChips[len], REG_OUT_EN_MSB, l_regColor[len]);
	}
}

void lighton()
{
	uint8_t len = sizeof(ledctlChips);
	while (len--)
	{
		l_regColor[len] = WHITE(0) | WHITE(1) | WHITE(2);
		I2C_Master_WriteBy2(ledctlChips[len], REG_OUT_EN_MSB, l_regColor[len]);
	}
}




void mpled_init() {
	uint8_t len = CHIPLEN;
	while (len--)
	{
		I2C_Master_WriteBy1(ledctlChips[len], REG_RESET, 0xFF);
		I2C_Master_WriteBy1(ledctlChips[len], REG_CNTRL1, 0x40);
		I2C_Master_WriteBy1(ledctlChips[len], REG_MISC, LP55231_AUTO_INC | LP55231_CP_AUTO | LP55231_AUTO_CLK);
		I2C_Master_WriteBy1(ledctlChips[len], REG_MASTER_FADER1, 0xFF);
		I2C_Master_WriteBy2(ledctlChips[len], REG_OUT_DIM_MSB, 0xFFFF);

		uint8_t regOffset = 8;
		do
		{
			I2C_Master_WriteBy1(ledctlChips[len], REG_D1_CONTROL + regOffset, LP55231_ENABLE);
			I2C_Master_WriteBy1(ledctlChips[len], REG_D1_PWM + regOffset, SINGPWMDEF);
			l_regColor[len] = DARK;
			I2C_Master_WriteBy2(ledctlChips[len], REG_OUT_EN_MSB, l_regColor[len]);
		} while (regOffset--);
	}
}



/*
* “Outside to Center”: on entry to Asleep mode. Runs only once.
* Color: White
* Command: 0x10
* Behavior: turn on two center LEDs, move out to the sides, then fade to off
*/
void mpled_outsideToCenter()
{
	//Clear execution buffer
	l_queLActend = 0;

	static uint8_t disToSide;
	const uint8_t halfBar = CHIPLEN * LEDINSIDE / 2;
	if (disToSide > halfBar)
	{
		lightoff();
		disToSide = 0;
		return;
	}

	uint8_t pairLft = disToSide;
	uint8_t pairRgt = halfBar + halfBar - disToSide - 1;
	uint8_t len = CHIPLEN;
	while (len--)
	{
		uint8_t inside = LEDINSIDE;
		while (inside--)
		{
			uint8_t ledPos = multipInt16(LEDINSIDE, len) + inside;
			if (ledPos == pairLft || ledPos == pairRgt)
				l_regColor[len] |= WHITE(inside);
			else
				l_regColor[len]BLACK(inside);
		}
		I2C_Master_WriteBy1(ledctlChips[len], REG_MASTER_FADER1, 0xFF);
		I2C_Master_WriteBy2(ledctlChips[len], REG_OUT_EN_MSB, l_regColor[len]);
	}

	{
		//Keep the two leds on for about 270ms.
		LEDACTION act =
		{
			.m_delay = 270,
			.m_stepnext = mpled_outsideToCenter
		};
		mpled_append(&act);
	}

	++disToSide;
}

/*
* “Center to Outside”: on exit from non-Asleep mode. Runs Only Once.
* Color: White
* Behavior: turn on two outside LEDs, move out to the sides, then fade to off
*/
void mpled_centerToOutside()
{
	//Clear execution buffer
	l_queLActend = 0;

	static uint8_t disToCenter;
	const uint8_t halfBar = CHIPLEN * LEDINSIDE / 2;
	if (disToCenter > halfBar)
	{
		lightoff();
		disToCenter = 0;
		return;
	}

	uint8_t pairLft = halfBar - disToCenter - 1;
	uint8_t pairRgt = halfBar + disToCenter;
	uint8_t len = CHIPLEN;
	while (len--)
	{
		uint8_t inside = LEDINSIDE;
		while (inside--)
		{
			uint8_t ledPos = multipInt16(LEDINSIDE, len) + inside;
			if (ledPos == pairLft || ledPos == pairRgt)
				l_regColor[len] |= WHITE(inside);
			else
				l_regColor[len]BLACK(inside);
		}
		printf("\r\ncenterToOutside attempting\r\n");
		I2C_Master_WriteBy1(ledctlChips[len], REG_MASTER_FADER1, 0xFF);
		I2C_Master_WriteBy2(ledctlChips[len], REG_OUT_EN_MSB, l_regColor[len]);
	}

	{
		//Keep the two leds on for about 270ms.
		LEDACTION act =
		{
			.m_delay = 270,
			.m_stepnext = mpled_centerToOutside
		};
		mpled_append(&act);
	}

	++disToCenter;
}


/*
* “Ball in Flight”; golf ball is being tracked and calculated
* Color: blue
* Command: 0x01
* Behavior: single blue LED going left and right.
*/
void mpled_ballInFlight()
{
	static int8_t ballPos;
	static bool isToLeft;

	//Calculate the ball position.
	if (!isToLeft)
	{
		if (++ballPos >= CHIPLEN * LEDINSIDE)
		{
			--ballPos;
			isToLeft = true;
		}
	}
	else
	{
		if (--ballPos < 0)
		{
			++ballPos;
			isToLeft = false;
		}
	}

	//Clear execution buffer
	l_queLActend = 0;

	uint8_t len = CHIPLEN;
	while (len--)
	{
		uint8_t inside = LEDINSIDE;
		while (inside--)
		{
			uint8_t ledPos = multipInt16(LEDINSIDE, len) + inside;
			if (ledPos == ballPos)
				l_regColor[len] |= BLUE(inside);
			else
				l_regColor[len]BLACK(inside);
		}
		I2C_Master_WriteBy1(ledctlChips[len], REG_MASTER_FADER1, 0xFF);
		I2C_Master_WriteBy2(ledctlChips[len], REG_OUT_EN_MSB, l_regColor[len]);
	}

	{
		LEDACTION act =
		{
			.m_delay = 270,
			.m_stepnext = mpled_ballInFlight
		};
		mpled_append(&act);
	}
}
/*
 * Wifi or blue tooth connect:
 * Color: White
 * Command: 0x06
 * Behavior: flash all LEDs to max brightness, then fade to off.
 */
void mpled_wifiOrBtConn()
{
    static uint8_t bright;
    static bool isDarker;

    if(!isDarker)
    {
        uint8_t newBright;
        if((newBright = bright + BRIGHTSTEP) > bright && newBright != 0xFF)
            bright = newBright;
        else
            isDarker = true;
    }
    else
    {
        uint8_t newBright;
        if((newBright = bright - BRIGHTSTEP) < bright && newBright != 0)
            bright = newBright;
        else
            isDarker = false;
    }

    //Clear execution buffer
    l_queLActend = 0;

    uint8_t len = CHIPLEN;
    while(len--)
    {
        I2C_Master_WriteBy1(ledctlChips[len], REG_MASTER_FADER1, bright);
        uint8_t inside = LEDINSIDE;
        while(inside--)
            l_regColor[len] |= WHITE(inside);
        I2C_Master_WriteBy2(ledctlChips[len], REG_OUT_EN_MSB, l_regColor[len]);
    }

    LEDACTION act =
    {
     .m_delay = 32,
     .m_stepnext = mpled_wifiOrBtConn
    };
    mpled_append(&act);
}

/*
 * “Armed”: Gold ball is on the tee and LM is seeking ball
 * Color: Blue
 * Command: 0x00
 * Behavior: LED’s “breathing” pattern. Possibly symmetrical width indicating battery
 * charge. All (12) LED’s means > 15/16 charge. 10 center LED’s mean >¾
 * charge. 8 center LED’s mean >½ charge., 6 center LED’s mean >¼ charge;
 * 4 center LED’s means <1/ charge.
 * If unit is charging, then ‘Pulse’ the outside LED’s.
 */
void mpled_armed()
{
    static uint8_t bright;
    static bool isDarker;

    if(!isDarker)
    {
        uint8_t newBright;
        if((newBright = bright + BRIGHTSTEP) > bright && newBright != 0xFF)
            bright = newBright;
        else
            isDarker = true;
    }
    else
    {
        uint8_t newBright;
        if((newBright = bright - BRIGHTSTEP) < bright && newBright != 0)
            bright = newBright;
        else
            isDarker = false;
    }

    //Clear execution buffer
    l_queLActend = 0;

	uint8_t rsoc = 100; //bat_rsoc();

    uint8_t ledBeg;
    uint8_t ledEnd;
    if(rsoc >= 93)
    {
        //12 center
        ledBeg = CHIPLEN * LEDINSIDE / 2 - 6;
        ledEnd = ledBeg + 12;
    }
    else if(rsoc >= 75)
    {
        //10 center
        ledBeg = CHIPLEN * LEDINSIDE / 2 - 5;
        ledEnd = ledBeg + 10;
    }
    else if(rsoc >= 50)
    {
        //8 center
        ledBeg = CHIPLEN * LEDINSIDE / 2 - 4;
        ledEnd = ledBeg + 8;
    }
    else if(rsoc >= 25)
    {
        //6 center
        ledBeg = CHIPLEN * LEDINSIDE / 2 - 3;
        ledEnd = ledBeg + 6;
    }
    else if(rsoc >= 1)
    {
        //4 center
        ledBeg = CHIPLEN * LEDINSIDE / 2 - 2;
        ledEnd = ledBeg + 4;
    }
    else
    {
        ledBeg = CHIPLEN * LEDINSIDE / 2 - 1;
        ledEnd = ledBeg + 2;
    }

    uint8_t len = CHIPLEN;
    while(len--)
    {
        I2C_Master_WriteBy1(ledctlChips[len], REG_MASTER_FADER1, bright);
        uint8_t inside = LEDINSIDE;
        while(inside--)
        {
            uint8_t ledPos = multipInt16(LEDINSIDE, len) + inside;
            if(ledPos >= ledBeg && ledPos < ledEnd)
                l_regColor[len] |= BLUE(inside);
            else
                l_regColor[len]BLACK(inside);
        }
        I2C_Master_WriteBy2(ledctlChips[len], REG_OUT_EN_MSB, l_regColor[len]);
    }

    LEDACTION act =
    {
     .m_delay = 32,
     .m_stepnext = mpled_armed
    };
    mpled_append(&act);
}

/*
 * “Error”; unit is not operable
 * Color: Red
 * Command: 0x04
 * Behavior: Center 4 LED’s flashing red at 3Hz
 */
void mpled_error()
{
    //Clear execution buffer
    l_queLActend = 0;

    //4 center
    const uint8_t ledBeg = CHIPLEN * LEDINSIDE / 2 - 2;
    const uint8_t ledEnd = ledBeg + 4;

    blink(ledBeg, ledEnd, LEDC_RED, 167, mpled_error);
}

/*
 * “Configuration”: Configuration in progress, such as Calibration, Firmware, Menu
 * Update
 * Color: Yellow
 * Command: 0x03
 * Behavior: Center 8 LED’s “pulsing” Yellow at 3Hz
 */
void mpled_configuration()
{
    //Clear execution buffer
    l_queLActend = 0;

    //8 center
    const uint8_t ledBeg = CHIPLEN * LEDINSIDE / 2 - 4;
    const uint8_t ledEnd = ledBeg + 8;

    blink(ledBeg, ledEnd, LEDC_YELLOW, 167, mpled_configuration);
}


/*
 * “Self Test”: Factory or User Self test
 * Color: All Colors
 * Command: 0x05
 * Behavior: Turn on All LED’s Red, then Green, then Blue, then White
 * Individually turn, on, left to right order, LED’s Red @4Hz Repeat for Blue
 * Green, and white.
 */
void mpled_selftest()
{
    static int8_t ledPos;
    static bool isToLeft;
    static bool chgPos;

    //Calculate the ball position.
    if(chgPos)
    {
        chgPos = false;
        if(!isToLeft)
        {
            if(++ledPos >= CHIPLEN * LEDINSIDE)
            {
                --ledPos;
                isToLeft = true;
            }
        }
        else
        {
            if(--ledPos < 0)
            {
                ++ledPos;
                isToLeft = false;
            }
        }
    }

    //Clear execution buffer
    l_queLActend = 0;

    static enum LEDCOLORS cols;

    uint8_t len = CHIPLEN;
    while(len--)
    {
        uint8_t inside = LEDINSIDE;
        while(inside--)
        {
            if(ledPos == multipInt16(LEDINSIDE, len) + inside)
                switch(cols)
                {
                case LEDC_RED:
                    l_regColor[len] = RED(inside);
                    cols = LEDC_GREEN;
                    break;
                case LEDC_GREEN:
                    l_regColor[len] = GREE(inside);
                    cols = LEDC_BLUE;
                    break;
                case LEDC_BLUE:
                    l_regColor[len] = BLUE(inside);
                    cols = LEDC_WHITE;
                    break;
                case LEDC_WHITE:
                    l_regColor[len] = WHITE(inside);
                    chgPos = true;
                    cols = LEDC_RED;
                    break;
                }
            else
                l_regColor[len]BLACK(inside);
        }
        I2C_Master_WriteBy1(ledctlChips[len], REG_MASTER_FADER1, 0xFF);
        I2C_Master_WriteBy2(ledctlChips[len], REG_OUT_EN_MSB, l_regColor[len]);
    }

    {
        LEDACTION act =
        {
         .m_delay = 250,
         .m_stepnext = mpled_selftest
        };
        mpled_append(&act);
    }
}

/*
 * “Standby LED Sequence”
 * Color: Red
 * Command: 0x07
 * Behavior:  Turn on center 4 Red even LED’s   Turn on center 4 odd LED’s. Cycle 1Hz rate.
 * Reference: Not specified by FSG.  Indicates waiting for user action to switch to “Armed” mode.
 */
void mpled_standby()
{
    static bool isOdd;

    //Clear execution buffer
    l_queLActend = 0;

    //8 center
    const uint8_t ledBeg = CHIPLEN * LEDINSIDE / 2 - 4;
    const uint8_t ledEnd = ledBeg + 8;

    uint8_t len = CHIPLEN;
    while(len--)
    {
        I2C_Master_WriteBy1(ledctlChips[len], REG_MASTER_FADER1, 0xFF);
        uint8_t inside = LEDINSIDE;
        while(inside--)
        {
            uint8_t ledPos = multipInt16(LEDINSIDE, len) + inside;
            if(ledPos >= ledBeg && ledPos < ledEnd)
            {
                //Counted from zero
                if(!((ledPos + isOdd) & 0x01))
                    //Odd
                    l_regColor[len] |= RED(inside);
                else
                    //Even
                    l_regColor[len]BLACK(inside);
            }
            else
                l_regColor[len]BLACK(inside);
        }
        I2C_Master_WriteBy2(ledctlChips[len], REG_OUT_EN_MSB, l_regColor[len]);
    }
    isOdd = !isOdd;

    LEDACTION act =
    {
     .m_delay = 1000,
     .m_stepnext = mpled_standby
    };
    mpled_append(&act);
}

static void mpled_insert(LEDACTION *action, uint8_t cursor)
{
    if(l_queLActend >= LACTIONDEEP)
        return ;

    uint8_t cursorB = cursor + 1;
    for(; cursorB < l_queLActend; ++ cursorB)
        l_queLAction[cursorB] = l_queLAction[(uint8_t)(cursorB - 1)];

    l_queLAction[cursor] = *action;
}

static void mpled_append(LEDACTION *action)
{
    if(l_queLActend >= LACTIONDEEP)
        return ;

    l_queLAction[l_queLActend++] = *action;
}

static void mpled_replace(LEDACTION *action, uint8_t cursor)
{
    if(cursor >= l_queLActend)
        return;

    l_queLAction[cursor] = *action;
}

void mpled_clear()
{
    l_queLActend = 0;
}

void mpled_processor()
{
	//There is no led actions to be proceed.
	if (l_queLActend == 0)
	{
		return;
	}

	LEDACTION action = l_queLAction[0];

	
	--l_queLActend;
	//Execute the led action at queue header.
	void(*stepnext)(void) = action.m_stepnext;
	uint8_t cursor = 0;
	//        for(; cursor < action.m_actionEnd; ++cursor)
	//            I2C_Master_WriteBy2(ledctlChips[action.m_actions[cursor].m_chipId],
	//                                action.m_actions[cursor].m_register,
	//                                action.m_actions[cursor].m_regData);
	//Erase the queue header.
	cursor = 1;
	for (; cursor < l_queLActend; ++cursor)
		l_queLAction[(uint8_t)(cursor - 1)] = l_queLAction[cursor];

	--l_queLActend;

	if (stepnext)
		stepnext();
	
}

static void blink(uint8_t ledBeg, uint8_t ledEnd, enum LEDCOLORS color, uint16_t halfPeriod, void (*stepnext)(void))
{
    static uint8_t bright;

    if(bright == 0xFF)
        bright = 0;
    else
        bright = 0xFF;

    uint8_t len = CHIPLEN;
    while(len--)
    {
        I2C_Master_WriteBy1(ledctlChips[len], REG_MASTER_FADER1, bright);
        uint8_t inside = LEDINSIDE;
        while(inside--)
        {
            uint8_t ledPos = multipInt16(LEDINSIDE, len) + inside;
            if(ledPos >= ledBeg && ledPos < ledEnd)
                switch(color)
                {
                default:
                    break;
                case LEDC_RED:
                    l_regColor[len] |= RED(inside);
                    break;
                case LEDC_YELLOW:
                    l_regColor[len] |= YELL(inside);
                    break;
                case LEDC_WHITE:
                    l_regColor[len] |= WHITE(inside);
                    break;
                }
            else
                l_regColor[len]BLACK(inside);
        }
        I2C_Master_WriteBy2(ledctlChips[len], REG_OUT_EN_MSB, l_regColor[len]);
    }

    //color light switch
    LEDACTION act =
    {
     .m_delay = halfPeriod,
     .m_stepnext = stepnext
    };
    mpled_append(&act);
}
