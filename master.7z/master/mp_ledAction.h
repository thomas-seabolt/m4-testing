/*
 * mp_ledAction.h
 *
 *  Created on: 2019-9-6
 *      Author: zhihui
 */

#ifndef MP_BOARD_MP_LEDACTION_H_
#define MP_BOARD_MP_LEDACTION_H_

#include <stdbool.h>
#include <stdint.h>

void lightoff();

void mpled_init();

void mpled_enable(bool en);

void mpled_outsideToCenter();

void mpled_centerToOutside();

void mpled_ballInFlight();

void mpled_wifiOrBtConn();

void mpled_armed();

void mpled_error();

void mpled_configuration();

void mpled_batteryCharging();

void mpled_selftest();

void mpled_standby();

void mpled_clear();

void mpled_processor();

bool mpled_test_i2c(uint8_t led_driver_chip);


#endif /* MP_BOARD_MP_LEDACTION_H_ */
