/*
 * acc.h
 *
 *  Created on: 2019-10-16
 *      Author: zhihui
 */

#ifndef MSP430G2755IRHA40T_ACC_H_
#define MSP430G2755IRHA40T_ACC_H_

#include <stdint.h>

int16_t multipInt16(int16_t base, int16_t cnt);

__attribute__((ramfunc))
int16_t devideInt16(int16_t divided, int16_t div);

__attribute__((ramfunc))
uint32_t devideUInt32(uint32_t divided, uint32_t div);


#endif /* MSP430G2755IRHA40T_ACC_H_ */
